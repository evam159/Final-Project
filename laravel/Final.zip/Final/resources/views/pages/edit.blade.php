@extends('layout.master')

@section('title')
    Edit Event
@endsection

@section('content')
<div class="container border border-dark">
    <div class="container pt-4">
        {{-- <div class="container pt-3"> --}}
            <h5><b>Edit event</b></h5>

                <form action="{{route('update', $events->id)}}" method="post">
                    @csrf

                    <div class="col-md-7 offset-md-3 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 40rem">
                                <div class="card-body">

                                    <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                        <label class="form-group mb-4"><b>New event</b></label>
                                        <input type="text" value="{{ $events->eventname }}" class="form-control" name ="event_input">
                                    </div>


                                        <div class="col-md-7 offset-md-1 mt-3" style="width: 18 rem">
                                            <label class="form-label fw-bold"><b>Date</b></label required>
                                            <input type="date" value="{{ $events->date }}" class="form-control" name="date">
                                        </div>
                                        
                                        <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                            <label class="form-group mb-4"><b>In Charge</b></label>
                                            <input type="text" value="{{ $events->incharge }}"  class="form-control" name ="incharge_input">
                                        </div>

                                        <div class="col-md-7 offset-md-1 mt-3" style="width:18 rem">
                                            <label class="form-group mb-4"><b>Venue</b></label>
                                            <input type="text" value="{{ $events->venue }}"  class="form-control" name ="venue_input">
                                        </div>

                                        <div class="pt-4">
                                            <div class="row">
                                                <div class="col-md-3 offset-md-3">
                                                    <input type="submit" value="Update" class="btn btn-success">
                                                </div>
                                                <div class="col-md-5">
                                                    <a href="#" id="cancel" class="btn btn-primary">Cancel</a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                        
                </div>
            {{-- </div> --}}
        </div>         
    </form>
</div>
    
@endsection