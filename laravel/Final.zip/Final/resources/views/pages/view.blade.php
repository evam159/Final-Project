@extends('layout.master')

@section('title')
    Event Details
@endsection
@section('content')
    <div class="container border border-dark bg-secondary">
        <nav class="navbar-light">
            <div class="container">
                <span class="navbar-brand mb-0 h1"><b>{{$events->eventname}}</b></span>
            </div>
        </nav>
    </div>
                <div class="container border border-dark">
                    <div class="col-md-5 offset-md-2 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 50rem">
                                <div class="card-body">
                                    <div class="col-md-7 offset-md-1 mt-3">
                                        <h5><b>Event Details</b><h5> 
                                            <div class="col-md-7 offset-md-5 pt-5">
                                                <h6>Schedule: {{ $events->date }} </h6><br></b>
                                                <h6>Venue: {{ $events->venue }}</h6><br></b>
                                                <h6>In Charge: {{ $events->incharge }}</h6>                                       
                                            </div>

                                            <div class="pt-4">                                          
                                                <div class="col-md-3 offset-md-7">
                                                    <a href="{{ route('main-page') }}" class="mt-2 btn btn-info">Back</a>
                                                </div>
                                            </div>
                                    </div>
                            </div>                            
                        </div>
                    </div>
                </div>

@endsection