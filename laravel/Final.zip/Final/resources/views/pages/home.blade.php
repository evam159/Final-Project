 @extends("layout.master")

 @section('title')
	 Management System
 @endsection
 
 @section('content')
	<div class="container border border-dark bg-secondary">
		<nav class="navbar-light">
			<div class="container">
				<span class="navbar-brand mb-0 h1"><b>Modified CRUD Demo</b></span>
			</div>
		</nav>
	</div>
		
		<div class="container border border-dark">
			<div class="container pt-4">
				<div class="container">
					<h5><b>Events Management System</b></h5>
						<div class="image pt-5">
							<a href="{{route('add')}}"><img src="images/add.png" width=" 20px" height="20 px"></a>	

								
									<div class="container ">
										<div class="row ">
											@foreach ($events as $event)
												<div class="col-md-3 offset-md-1 pt-5">
													<div class="card bg-light" style="width: 15 rem;">
														<div class="card-body border border-dark rounded">
															
																<div> 
																	<div class="col-md-7 offset-md-10">
																		<div style="position: relative">
																			<a href="{{route('destroy', $event->id)}}" onclick="return confirm('Delete {{$event->eventname}}?');">
																			<img src="images/delete.png" width=" 25px" height="20 px"></a>
																		</div>
																	</div>

																		
																			<div>									
																				<div class="card-title offset-md-1 pt-2 ">
																					<span><b>{{$event->eventname}}</b></span><br>

																					<center>
																						<div class="pt-4">
																							<a href="{{route('view', $event->id)}}" class="btn btn-primary " name="view_event" >View</a>
																							<a href="{{route('edit', $event->id)}}" class="btn btn-info offset-md-1 ">Edit</a>																		
																						</div>
																					</center>
																				</div>																	
																			</div>											
																</div>														
														</div>
													</div>
												</div>
											@endforeach	
										</div>
									</div>
						</div>
					</div>
				</div>
			</div>
		</div>

 @endsection