

<?php $__env->startSection('title'); ?>
    Event Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container border border-dark bg-secondary">
        <nav class="navbar-light">
            <div class="container">
                <span class="navbar-brand mb-0 h1"><b><?php echo e($events->eventname); ?></b></span>
            </div>
        </nav>
    </div>
                <div class="container border border-dark">
                    <div class="col-md-5 offset-md-2 pt-5">
                        <div class="container">
                            <div class="card bg-light" style="width: 50rem">
                                <div class="card-body">
                                    <div class="col-md-7 offset-md-1 mt-3">
                                        <h5><b>Event Details</b><h5> 
                                            <div class="col-md-7 offset-md-5 pt-5">
                                                <h6>Schedule: <?php echo e($events->date); ?> </h6><br></b>
                                                <h6>Venue: <?php echo e($events->venue); ?></h6><br></b>
                                                <h6>In Charge: <?php echo e($events->incharge); ?></h6>                                       
                                            </div>

                                            <div class="pt-4">                                          
                                                <div class="col-md-3 offset-md-7">
                                                    <a href="<?php echo e(route('main-page')); ?>" class="mt-2 btn btn-info">Back</a>
                                                </div>
                                            </div>
                                    </div>
                            </div>                            
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\True\SQL\Laravel App\Final\resources\views/pages/view.blade.php ENDPATH**/ ?>