
<?php $__env->startSection('title'); ?>
 To do list
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<h1> THIS IS HOME </h1>
		<a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">Add Task</a>

		<div clas="col-md-8 offset-md-2">
			<table class="table">
				<thead>
					<tr>
						<td>ID</td>
						<td>Task</td>
						<td>Done</td>
						<td>Edit</td>
						<td>Delete</td>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($task->id); ?></td>
						<td><a href="<?php echo e(route('tasks.show', $task->id)); ?>"><?php echo e($task->task_column); ?></a></td>
						<td>
							<?php if($task->done === 0): ?>
								<a href="<?php echo e(route('done', $task->id)); ?>">False</a>
							<?php else: ?>
								<a href="<?php echo e(route('done', $task->id)); ?>">True</a>
							<?php endif; ?>
						</td>
						
						<td><a href="<?php echo e(route('tasks.edit',$task->id)); ?>"class="btn btn-secondary" >Edit</a></td>
						<td>
                            <a href="#" onclick="return confirm('Are you Sure you want to delete');"> 
                            <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="post"> 
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type=submit class="btn btn-danger">Delete</button>
                        </form> </a>
                        </td>
						
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\True\SQL\Laravel App\App-a5\resources\views/pages/home.blade.php ENDPATH**/ ?>