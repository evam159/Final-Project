
<?php $__env->startSection('title'); ?>
    Specific Task
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
        <h3>The Task is to <?php echo e($task->task_column); ?></h3>
        <h5>is it done?  <br>
            <?php if($task->done == 0): ?>
            <span class="text-danger">Not yet done.</span>
            <?php else: ?>
            <span class="text-success">Yes. It is done.</span>
            <?php endif; ?>
        </h5>

    <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-secondary">Back</a>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\True\SQL\Laravel App\App-a5\resources\views/pages/task.blade.php ENDPATH**/ ?>