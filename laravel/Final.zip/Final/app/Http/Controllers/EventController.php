<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;
use Illuminate\Support\Facades\Date;

class EventController extends Controller
{
    public function show(){
        $events = Event::all();
        

        return view("pages.home")->with("events", $events);
    }

    public function insert(Request $request){
        
        // $this->validate($request,[
          
        // ]);
        $events = new Event();

        $events->eventname = $request->event_input;
        $events->date = $request->date;
        $events->venue= $request->venue_input;
        $events->incharge = $request->incharge_input;
        

        $events->save();
        return redirect()->route('main-page');

    }
    public function edit($id){
        
        $events = Event::find($id);
            return view("pages.edit")->with("events", $events);
    
        }
    
        public function update(Request $request,$id){
    
            $events = Event::find($id);
            $events->eventname = $request->event_input;
            $events->date = $request->date;
            $events->venue= $request->venue_input;
            $events->incharge = $request->incharge_input;
            
            $events->save();
            return redirect()->route('main-page');
        }
        public function destroy($id){
            $events = Event::find($id);
            $events->delete();
    
            return redirect()->route('main-page');   
        }

        public function view($id){
          
            $events=Event::find($id);
            return view("pages.view")->with("events", $events);
        }
    
}
